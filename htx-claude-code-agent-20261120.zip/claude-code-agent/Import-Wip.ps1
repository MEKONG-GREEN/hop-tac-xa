[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$RepoPath,
    [switch]$Apply,
    [ValidatePattern('^feature/AH-278-[A-Za-z0-9._/-]+$')][string]$Branch = 'feature/AH-278-chia-se-htx-handoff'
)
$ErrorActionPreference='Stop'
$repo=(Resolve-Path -LiteralPath $RepoPath).Path
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'wip/manifest.json') -Raw | ConvertFrom-Json
$patch=Join-Path $PSScriptRoot 'wip/AH-278-AH-274.patch'
if ((Get-FileHash -LiteralPath $patch -Algorithm SHA256).Hash -ne $manifest.patchSha256) { throw 'Patch checksum mismatch.' }
$origin=& git -C $repo remote get-url origin
if ($LASTEXITCODE -ne 0 -or $origin.TrimEnd('/') -notin @('https://github.com/MEKONG-GREEN/hop-tac-xa.git','https://github.com/MEKONG-GREEN/hop-tac-xa','git@github.com:MEKONG-GREEN/hop-tac-xa.git','ssh://git@github.com/MEKONG-GREEN/hop-tac-xa.git')) { throw 'Wrong Git origin.' }
$dirty=@(& git -C $repo status --porcelain)
if ($LASTEXITCODE -ne 0 -or $dirty.Count -gt 0) { throw 'Import requires a clean working tree. Do not overwrite existing WIP.' }
& git -C $repo cat-file -e "$($manifest.baseCommit)^{commit}"
if ($LASTEXITCODE -ne 0) { throw 'Base commit unavailable. Fetch origin dev-agent, then retry.' }
if ($Apply) {
    & git -C $repo check-ref-format --branch $Branch | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Invalid branch name.' }
    & git -C $repo show-ref --verify --quiet "refs/heads/$Branch"
    if ($LASTEXITCODE -eq 0) { throw 'Destination branch already exists; inspect it instead of importing twice.' }
    & git -C $repo switch -c $Branch $manifest.baseCommit
    if ($LASTEXITCODE -ne 0) { throw 'Cannot create handoff branch.' }
} else {
    & git -C $repo merge-base --is-ancestor $manifest.baseCommit HEAD
    if ($LASTEXITCODE -ne 0) { throw 'Current checkout does not contain the handoff base. Use a checkout of dev-agent containing that commit.' }
}
& git -C $repo apply --check --whitespace=nowarn $patch
if ($LASTEXITCODE -ne 0) { throw 'Patch does not apply cleanly. No patch content was applied.' }
if (-not $Apply) { Write-Host 'Checksum and git apply --check passed. No code was changed.'; return }
& git -C $repo apply --whitespace=nowarn $patch
if ($LASTEXITCODE -ne 0) { throw 'Patch import failed; inspect the working tree before retrying.' }
Write-Host "Imported unfinished AH-278/AH-274 changes on $Branch. No commit, Jira update, PR or merge was performed."
Write-Host 'Read HANDOFF.md, review all changes, sync latest dev-agent and complete required validation before PR.'
