[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$RepoPath,
    [ValidatePattern('^AH-[1-9][0-9]*$')][string]$Ticket = 'AH-278',
    [ValidateSet('Audit','Run')][string]$Mode = 'Audit',
    [ValidateRange(1,20)][int]$MaxPackages = 1,
    [switch]$Headless,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
$kit = $PSScriptRoot
$repo = (Resolve-Path -LiteralPath $RepoPath).Path
$policy = Join-Path $kit 'AGENT.md'
$handoff = Join-Path $kit 'HANDOFF.md'
foreach ($file in @($policy,$handoff,(Join-Path $repo 'AGENTS.md'))) {
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing required file: $file" }
}
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is required.' }
$root = & git -C $repo rev-parse --show-toplevel
if ($LASTEXITCODE -ne 0) { throw 'RepoPath is not a Git checkout.' }
if ((Resolve-Path -LiteralPath $root).Path -ne $repo) { throw 'RepoPath must be the repository root.' }
$origin = & git -C $repo remote get-url origin
if ($LASTEXITCODE -ne 0 -or $origin.TrimEnd('/') -notin @(
    'https://github.com/MEKONG-GREEN/hop-tac-xa.git',
    'https://github.com/MEKONG-GREEN/hop-tac-xa',
    'git@github.com:MEKONG-GREEN/hop-tac-xa.git',
    'ssh://git@github.com/MEKONG-GREEN/hop-tac-xa.git'
)) { throw 'Git origin does not match the authorized HTX repository.' }
$branch = & git -C $repo branch --show-current
if ($LASTEXITCODE -ne 0) { throw 'Cannot read branch.' }
$dirty = @(& git -C $repo status --porcelain)
if ($LASTEXITCODE -ne 0) { throw 'Cannot read working tree.' }
Write-Host "Mode=$Mode Ticket=$Ticket MaxPackages=$MaxPackages Branch=$branch DirtyPaths=$($dirty.Count)"
if ($dirty.Count -gt 0) { Write-Host 'Existing changes must be reviewed and preserved; no automatic cleanup.' }
if ($CheckOnly) {
    Write-Host 'Local checks passed. No Claude/MCP call or repository mutation was made.'
    return
}
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) { throw 'Install/login Claude Code first; see README.md.' }
$prompt = @"
Mode=$Mode; Ticket=$Ticket; MaxPackages=$MaxPackages; scopeEpic=AH-265; targetBranch=dev-agent.
Read AGENTS.md and applicable CLAUDE.md/instructions in this checkout, then read "$handoff".
Use the team's existing Jira and GitHub MCP servers. Discover tools and verify the exact site/repository before acting.
Audit is read-only and preserves the owner's stop instruction. Run explicitly authorizes this new team session to execute the specified packages, self-review, all CI and merge dev-agent only under AGENT.md.
Start with a fresh requirement/comment/dependency check; preserve all dirty WIP. Do not re-import an already applied patch. Respect the package limit and any new stop instruction.
"@
# Put the positional prompt first so --add-dir's variadic values cannot swallow it.
$claudeArgs = @($prompt, '--append-system-prompt-file', $policy, '--add-dir', $kit)
if ($Mode -eq 'Audit') { $claudeArgs += @('--permission-mode','plan') }
if ($Headless) { $claudeArgs += @('--print','--output-format','text') }
Push-Location -LiteralPath $repo
try {
    & claude @claudeArgs
    if ($LASTEXITCODE -ne 0) { throw "Claude Code exited with code $LASTEXITCODE. Check MCP/auth/permission output; no automatic retry." }
} finally { Pop-Location }
