# Trạng thái bàn giao — 20/11/2026, Asia/Bangkok

## Điểm bắt đầu

- Jira board: https://mkg-apphtx.atlassian.net/jira/core/projects/AH/board
- GitHub: https://github.com/MEKONG-GREEN/hop-tac-xa
- Nhánh tích hợp: **dev-agent**, không phải dev.
- Base bàn giao: `c77b478e3c9437197d745285bf331d1b93f4ef90` — merge PR #41.
- Phần đang dở: nhánh `feature/AH-278-chia-se-htx`, HEAD vẫn ở base trên, diff chưa commit. Nhánh này chưa được push/PR từ phiên bàn giao. Bản patch trong gói chứa cả tracked diff và untracked source.
- Lệnh cuối của chủ repo: **dừng các ticket**. Phiên đóng gói không tiếp tục code, test nghiệp vụ, Jira transition, push hay merge. Team chỉ tiếp tục khi tự chạy Mode Run/chỉ đạo mới.
- Jira AH-278 và AH-274: trạng thái đọc xác nhận gần nhất là `New`. Lệnh chuyển trạng thái đã bị chặn sau yêu cầu dừng; không được coi đã In Progress. Phải đọc lại qua MCP khi bắt đầu.

## Đã hoàn tất, không làm lại

| Ticket | PR / merge | Bằng chứng |
|---|---|---|
| AH-275 | https://github.com/MEKONG-GREEN/hop-tac-xa/pull/41 ; merge `c77b478e3c9437197d745285bf331d1b93f4ef90` | Đủ 5 job CI SUCCESS ở head `0712fb0c0e6e54c6dd6a910676414903f644392f`, run `44721403855`. Đã fetch, kiểm ancestry và tree sau merge. Jira xác nhận `READY TO BUILD`, category done. |
| AH-99 | PR #40 ; merge `6d5eef6b394f68d135ba8811968ad4b70e21cdf8` | CI `44698863283` đủ 5 job, Jira done. |
| AH-282 | PR #39 ; merge `e55de25003a603a6622e895c4e0de64c494e6348` | CI `44686284307` đủ 5 job, Jira done. |
| AH-285 | PR #38 ; merge `f37d537f55e5c6f05581e120ccf0ebc158a73eac` | CI `44681992710` đủ 5 job, Jira done. |

AH-273/AH-283, AH-51/AH-271 cũng đã hoàn tất theo phiên trước; kiểm lại code/Jira nếu là dependency mới. Repo/CI là nguồn xác nhận, không chỉ bảng này.

AH-275 đã có native account create/list, saga IAM bền, mật khẩu tạm một lần, realm HTX, chọn vai theo phép giao, ràng buộc idempotency/queue offline theo vai. Review cuối bổ sung member write guard sau bước chọn vai, đã nằm trong head CI xanh. Tài liệu quyết định đầy đủ: `docs/adr/0062-realm-htx-fn07.md` trên dev-agent. Chưa deploy hoặc tự migrate người dùng thật.

## Ba quyết định nghiệp vụ đã chốt

1. **FN-07**: mỗi account gắn đúng một HTX; một vai hoặc tối đa hai vai Đại diện/Thành viên trong cùng HTX. Admin tách riêng, không gắn HTX. Đặt lại mật khẩu qua OTP. Không triển khai mô hình multi-HTX của FN-TK02/AH-223.
2. **VTKM-Q-07 / AH-274**: Đại diện và Thành viên được mở danh sách và xuất Excel chỉ đọc cho danh mục dùng chung Vật tư/Kho/Máy móc. Không suy rộng quyền này sang mọi màn masterdata/FN-02.
3. **Mật khẩu**: tách realm `agrigreen-htx`, dùng mật khẩu tạm 8 chữ/số, buộc đổi lần đầu. Giữ realm KN `agrigreen` min12 theo ADR-0041. API/Vault/web/app/worker của bản HTX cùng issuer; không tạo token fallback đa realm.

Không hỏi lại các lựa chọn này. Có requirement/comment mới mâu thuẫn thì trình rõ khác biệt để chủ nghiệp vụ quyết định.

## Dependency và thứ tự tiếp theo

`AH-273 + AH-283 (done) → AH-275 (done) → AH-278 → AH-274 → AH-284 / AH-286`.

AH-278/274 đều High theo lần đọc trước. Formal link 274 phụ thuộc 278, nhưng AC02/03/08 của 278 lại cần phạm vi chia sẻ 274 để kiểm chứng; nên có thể làm chung một gói PR. Không đánh Done 278 chỉ vì CRUD yêu cầu đã xong. AH-223 chỉ Related, không Blocks. AH-270 có phần chọn vai trong AH-275 nhưng phần chia sẻ còn chưa hoàn tất; không đánh cả AH-270 Done. Scope tiếp tục là các ticket còn lại của epic AH-265, không tự triển khai AH-266.

### AH-278 — FN-09

- A gửi yêu cầu để **A xem B**, B duyệt/từ chối; pending chưa có quyền đọc. Chiều B xem A là yêu cầu độc lập.
- Chỉ Đại diện thao tác. Admin không gửi/duyệt/từ chối/thu hồi/chặn. Member không menu/route, API deny.
- Pending: A được rút, B không rút thay A. Approved: A hoặc B được thu hồi. Không xóa lịch sử. Một cặp có hướng tối đa một pending/approved; không tự gửi cho chính mình.
- Duyệt cấp quyền ngay, thu hồi mất quyền ngay ở request tiếp theo, không relogin. Chỉ đọc; hộ chia sẻ che SĐT 4 đầu/3 cuối, CCCD 3 đầu/3 cuối.
- Web: Gửi đến / Đã gửi, số chờ duyệt, trạng thái, gửi yêu cầu, toàn bộ dữ liệu chỉ xem, chiều chia sẻ rõ. Chưa chọn HTX: `Bắt buộc nhập`; không còn ứng viên: `Chưa có HTX để gửi yêu cầu`.
- Thông báo FN-09/BR-06 tách S12, không đưa vào gói này.

### AH-274 — FN-06

- Admin toàn hệ thống; Rep own + HTX đã duyệt chia sẻ chỉ đọc; Member own-only kể cả coop có shares.
- Server kiểm chức năng + scope, giữ actor/tenant/org gốc. Revoke ảnh hưởng danh sách, detail, thống kê, hộ và export/replay phù hợp; kiểm grant hiện tại.
- Khi dữ liệu bị thu hồi, UI không giữ lại dữ liệu cũ: thông báo `HTX đã ngừng chia sẻ dữ liệu cho HTX của bạn`, quay về danh sách HTX. Shared screens chỉ web; app chỉ own HTX.
- Phần danh mục dùng chung và Excel theo quyết định VTKM nêu trên vẫn cần triển khai/kiểm chứng.

### AH-284 — FN-03

- Danh sách Admin all, Rep own-first + approved shares, bộ lọc All/Own/Shared; Member own-only. HTX ngang hàng, không hierarchy HTX chính/liên kết.
- Diện tích từng HTX lấy tổng hộ từ AH-285, máy theo loại từ nguồn đúng AH-283; không cộng gộp shared HTX. Thiếu nguồn máy hiện `—`.
- Admin CRUD mọi HTX, Rep sửa own-only, shared readonly. Tab chia sẻ Rep trên own, Admin đọc-only, Member không có. App thông tin own readonly.

### AH-286 — FN-04

- Hộ shared chỉ đọc trên web; một hộ một HTX, revoke mất quyền ngay. Own Rep full contacts; shared server masking 4+3 / 3+3; Member own masked.
- Vault dùng owner proof mới và principal gốc. Không giả vai Vault, OrgRef hoặc purpose để đọc hộ của người khác.

## Code đang dở trong patch

- Cooperative member domain: request/state machine có hướng; test approve/reject/revoke theo đúng bên, terminal history.
- Migration mới `20261120104731_pf_cooperative_native_sharing.up.sql`: current request, append-only ledger, durable actor/key replay receipt, unique active ordered pair, RLS participant, publication/lifecycle guards.
- Native service/store/HTTP: `/v1/htx-sharing`, `/candidates`, `/{ref}/transitions`; role/tenant kiểm, org ports ngoài tx, revision lock, metadata labels ngoài tx.
- Native read helper: tx vật lý READ ONLY, giữ node gốc, opt-in GUC local; SQL helper kiểm approved grant đang hiệu lực. `USING` có nhánh shared-read nhưng `WITH CHECK` giữ rule cũ. Cần review/test DELETE/UPDATE và tất cả owner/policy consumers kỹ.
- Party narrow port và wiring để list/detail đọc own + live shares, recheck sau ghép số liệu.
- Household scope/profile/list và Vault owner proof có `shared`, contact masked, không write, recheck revoke qua callback.
- OpenAPI source fragment và aggregate/generated TS qua generator.
- Web `NativeSharing` và route `/htx/chia-se`, menu FN-09, mock/registration, UI tests.

Không tái sử dụng sharing cũ ở `internal/platform/party/app/sharing.go`: đó là cross-tenant partner/MKG, hai Admin và projection eventual. FN-09 mới là same-tenant, do Rep quyết định, revoke tức thì.

## Validation và việc còn mở

Các kết quả dưới đây đã chạy trên các snapshot trong quá trình làm, **chưa thay thế full validation của toàn bộ patch cuối**:

- Go domain state-machine: PASS.
- PostgreSQL thật: `TestNativeSharingWorkflowAndAuthorization`: PASS; hồi quy FN06 households: PASS.
- API → Vault → owner callback, PF pool một kết nối: `TestNativeSharingReadsMaskedHouseholdsAndRevokesWithoutLogin`: PASS (pending deny, approve masked, shared write deny, Member deny, same-token revoke deny).
- Hồi quy `TestAH285NativeCRUDAndReplayWithRealVault`: ban đầu FAIL vì helper RLS thiếu quyền cho owner; đã bổ sung execute đúng `own_cooperative`, chạy lại PASS cùng hai test chia sẻ.
- Go build toàn repo: PASS trước các sửa nhỏ cuối; archlint lần cuối PASS sau bỏ tenant.WithID dư thừa, không thêm allowlist.
- Web generator: PASS; typecheck chạy qua trước UI test. UI test: **2 PASS / 1 FAIL**. Failure ở `NativeSharing.test.tsx` khoảng dòng 40: `Found multiple elements with the text: Thu hồi` (status trên bảng và option filter). Cần scope assertion vào bảng/dòng hoặc element ngữ nghĩa; không bỏ kiểm tra hoặc nới test.
- Chưa full vet/golangci/modgen/migratecheck/contractcheck/docscheck, chưa full Go/web/Flutter/CI trên patch; chưa PR, chưa merge.

Ưu tiên tiếp nhận:

1. Đọc fresh Jira/comment/dependency và review patch trước khi code. Đồng bộ dev-agent mới nhất. Chạy gofmt và generator; migration chưa merge nên nếu base có timestamp mới cần sinh tên UTC mới, cập nhật tham chiếu hợp lệ.
2. Sửa UI assertion, bổ sung test approve/reject/incoming và xử lý refresh/revoke, conflict/retry/idempotency/concurrency. Tách bug product nếu có; không coi lỗi test này chứng minh toàn màn đã đúng.
3. Kiểm RLS shared read, direct SQL write/DELETE, empty/stale projection, cross-tenant, Member selected role, cached/export path và race revoke; test owner/private-reference/publication/deletion regressions.
4. Kiểm Party wiring/list/detail ở assembly thật; thêm tests own/shared across commune, recheck sau ports, per-HTX totals. Quyền ghi tuyệt đối own-only. Review mọi consumer của owner proof, gồm photo-key/identity registration và command paths.
5. Hoàn tất UI shared readonly và redirect sau revoke; native profile masks dùng câu chữ phù hợp cả shared Rep và Member. Mock sharing state đã có nhưng `nativeSharedRefs` chưa nối đầy đủ vào mock cooperative/household flows; phải hoàn thiện và kiểm để mock khớp backend.
6. Hoàn thiện acceptance scope AH-274, gồm danh mục/Excel. Chưa làm phần AH-284 own-first/filters/sharing tab/app và AH-286 shared readonly UI đầy đủ. Chỉ Done khi AC ticket tương ứng thật sự đạt; có thể tách PR theo gói có nghĩa.
7. Đầy đủ local gates, tự review, PR vào dev-agent, đủ mọi CI ở đúng HEAD rồi merge. Cập nhật Jira sau merge, sau đó chọn việc tiếp theo nếu còn quota.

## Những thứ không đóng gói

Không đưa `.tools` riêng, token, SMTP/IAM secret, test DB DSN/password, Docker volumes, transcript hoặc home config vào gói. Container test cũ trên máy gốc không phải hạ tầng của team. Team tự dựng môi trường test qua quy trình repo. Không xóa container/worktree khác khi nhận bàn giao.

Repo gốc còn worktree việc riêng AH-311; không nằm trong patch. Bản bàn giao không chạm hoặc đưa code AH-311 vào nhánh tích hợp.
