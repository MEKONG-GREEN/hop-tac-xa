# Bàn giao agent HTX cho Claude Code

Gói ngày 20/11/2026. Dùng **MCP Jira và GitHub đã cấu hình trong Claude Code**; không cần Jira API token, GitHub token hoặc MCP config mới trong gói này.

Đây là bộ khởi chạy và quy trình để Claude Code điều phối công việc trong repo hiện có, kèm bản vá công việc đang dở. Không phải dịch vụ daemon/webhook độc lập. Script không tự cài phần mềm, không tự chạy ticket khi giải nén.

## Chạy nhanh trên PowerShell 7

Cần Git, Claude Code đã đăng nhập và hai MCP Jira/GitHub hoạt động. Khi triển khai cần thêm Go/Node/Flutter/Docker theo repo. Git phải có quyền clone/fetch/push qua credential của máy; kết nối GitHub MCP không tự cấu hình credential cho Git.

Giải nén gói, mở PowerShell tại thư mục `claude-code-agent`:

```powershell
# Chỉ cần clone nếu máy chưa có repo.
git clone --branch dev-agent https://github.com/MEKONG-GREEN/hop-tac-xa.git
$repo = (Resolve-Path ./hop-tac-xa).Path

# Xác nhận local setup; không gọi MCP, không chạy model, không sửa repo.
pwsh -File ./Start-Agent.ps1 -RepoPath $repo -CheckOnly

# Claude chỉ đọc code/Jira/GitHub để đối chiếu kế hoạch. Mặc định là Audit.
pwsh -File ./Start-Agent.ps1 -RepoPath $repo -Ticket AH-278

# Khi team quyết định bắt đầu triển khai: một gói việc, tự review/CI/merge dev-agent.
pwsh -File ./Start-Agent.ps1 -RepoPath $repo -Ticket AH-278 -Mode Run
```

Nếu repo đã có trên máy, gán `$repo` bằng đường dẫn repo đó. Không cần clone lại. `Run` là chỉ đạo mới cho phiên Claude của team; gói bàn giao hiện vẫn ở trạng thái dừng. Chế độ Run giữ nguyên thiết lập permissions/MCP của team; không bật bypass. Claude có thể vẫn hiện yêu cầu cấp quyền theo chính sách máy/tổ chức.

Để chạy tiếp tối đa 3 gói trong phạm vi AH-265 theo dependency/priority:

```powershell
pwsh -File ./Start-Agent.ps1 -RepoPath $repo -Ticket AH-278 -Mode Run -MaxPackages 3
```

`-Headless` dùng `claude -p`, phù hợp khi permissions và MCP đã được team cấu hình cho chạy không tương tác. Hết phiên không có scheduler tự khởi động lại. Không dùng `-Headless` để né một yêu cầu quyền chưa được cấp.

## Tiếp nhận code AH-278/AH-274 đang dở

Đọc `HANDOFF.md` trước. Bản vá **chưa sẵn sàng merge**; chưa có PR/CI đầy đủ. Chỉ sao chép code đang dở, không coi test đã hoàn tất.

```powershell
git -C $repo fetch origin dev-agent

# Mặc định kiểm checksum, repo sạch, base và khả năng áp dụng; chưa sửa code.
pwsh -File ./Import-Wip.ps1 -RepoPath $repo

# Chỉ khi muốn nhận phần code đang dở: tạo nhánh riêng tại base chính xác và áp patch.
pwsh -File ./Import-Wip.ps1 -RepoPath $repo -Apply

pwsh -File ./Start-Agent.ps1 -RepoPath $repo -Ticket AH-278 -Mode Run
```

Import yêu cầu checkout sạch. Nếu đang dùng worktree AH-278 cũ còn code đang dở thì **không import lần hai**; chỉ chạy Audit/Run ở worktree đó. Script từ chối ghi đè nhánh hoặc working tree bẩn. `-Apply` tạo nhánh từ commit bàn giao; Claude phải đồng bộ với `origin/dev-agent` mới nhất và xử lý migration/dependency trước PR.

## Bên trong gói

| Tệp | Mục đích |
|---|---|
| `Start-Agent.ps1` | Khởi chạy Claude, Audit mặc định, Run khi chỉ định |
| `AGENT.md` | Quy trình Jira → đánh giá requirement → plan → code → review → CI → PR/merge |
| `HANDOFF.md` | Repo/Jira, quyết định nghiệp vụ, dependency, bằng chứng đã làm và lỗi còn mở |
| `Import-Wip.ps1` | Kiểm và nhận bản vá vào nhánh riêng |
| `wip/AH-278-AH-274.patch` | Toàn bộ diff đang dở, gồm cả tệp chưa tracked |
| `wip/manifest.json` | Base commit, danh sách tệp, SHA-256 của patch |
| `VERIFY.md` | Những gì đã kiểm với chính bộ bàn giao |

Không đóng gói `.env`, token, transcript chat, log thô, database, node_modules hoặc cấu hình MCP cá nhân. Không thay đổi credential của team.

## Công cụ và kiểm thử của repo

Nguồn chính xác là `AGENTS.md`, hướng dẫn cấp thư mục và `.github/workflows/ci.yml` ở checkout đang làm. Tại base bàn giao: Go toolchain `go1.26.10`, Node `>=24` (CI Node 24), golangci-lint `2.14.0`, Flutter `3.47.5`, JDK 17 cho APK; PostgreSQL 17 + PostGIS/pgRouting, PgBouncer cho CI. Có Dockerfile tại `deploy/compose/postgres`. Không tự dùng DB production cho test.

Trước lệnh Go trên PowerShell:

```powershell
$env:GOTOOLCHAIN = (Select-String '^toolchain ' "$repo/go.mod").Line.Split(' ')[1]
go version
```

Agent phải chạy đầy đủ cổng trong repo và chờ **đủ 5 job CI ở đúng PR HEAD**. Bộ Go race/RLS thực tế có thể mất khoảng nửa giờ. Test DB thiếu cấu hình sẽ SKIP; SKIP không được báo PASS. Không cần Jira REST script cũ hoặc GitHub CLI nếu MCP cung cấp đủ thao tác. Khi MCP thiếu đọc log/checks, báo đúng capability thiếu rồi dùng CLI đã xác thực nếu có.

## Kiểm tra MCP

Trong Claude Code dùng `/mcp` để xem kết nối sẵn có. Agent sẽ tự khám phá tool/schema, kiểm đúng site Jira và repo trước mọi ghi. MCP chỉ đọc thì Audit vẫn chạy được, Run sẽ báo thiếu capability ghi/merge cụ thể. Tên MCP/tool tùy cấu hình team, không hardcode trong gói.

Tài liệu CLI dùng để đối chiếu launcher: https://code.claude.com/docs/en/cli-reference ; hướng dẫn project memory: https://code.claude.com/docs/en/memory . Launcher dùng `--append-system-prompt-file`, giữ hướng dẫn mặc định của Claude và cấu hình MCP của team.
