# Kiểm chứng gói bàn giao

Thực hiện ngày 20/11/2026 trên Windows/PowerShell 7; Claude Code CLI cài trên máy là `2.1.296`. Đối chiếu flag với CLI help và tài liệu chính thức https://code.claude.com/docs/en/cli-reference .

| Kiểm tra | Kết quả |
|---|---|
| PowerShell parser cho Start-Agent.ps1 và Import-Wip.ps1 | PASS |
| Start-Agent -CheckOnly trên worktree WIP thật | PASS; giữ nguyên 35 đường dẫn đang đổi |
| Launcher mặc định Audit + permission-mode plan | PASS, kiểm bằng hàm Claude giả |
| Run truyền Ticket/MaxPackages và kế thừa permissions | PASS, kiểm bằng hàm Claude giả |
| Headless dùng --print; prompt/file/path được truyền đúng | PASS, kiểm bằng hàm Claude giả |
| Đường dẫn có khoảng trắng, khôi phục working directory | PASS |
| Ticket sai định dạng / origin repo khác | Từ chối đúng |
| Patch SHA-256 và git apply --check tại base c77b478 | PASS trên checkout biệt lập |
| Import -Apply vào nhánh kiểm chứng riêng | PASS; SHA-256 nội dung cả 35 file khớp worktree nguồn |
| Import lặp trên checkout bẩn | Từ chối đúng, không ghi đè |
| Patch đã bị chỉnh byte | Từ chối đúng qua checksum |

Patch gồm **19 tệp tracked thay đổi + 16 tệp mới**, tổng **97.285 byte**. SHA-256 nằm trong `wip/manifest.json`.

Chưa chạy phiên model Claude thật hoặc gọi MCP của team trong bước đóng gói. Không xác nhận thay team về authentication, permissions, tên/tool schema hay capability của MCP. Launcher không cài/ghi đè MCP config. Chỉ team mới có môi trường kết nối đó để kiểm Audit.

Không chạy lại test nghiệp vụ/CI của ticket sau yêu cầu dừng. Kiểm chứng import chỉ xác nhận nhận đủ đúng code; bản patch chưa sẵn sàng merge. Xem lỗi UI test và validation còn thiếu ở `HANDOFF.md`.

Không push/PR/merge, chuyển trạng thái Jira hoặc chạy deploy trong quá trình bàn giao. Các worktree ticket gốc và source chưa commit được giữ nguyên.
